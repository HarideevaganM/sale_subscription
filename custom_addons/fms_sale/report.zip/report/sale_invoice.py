from odoo import api, fields, models, _
        
class SaleInvoiceReport(models.AbstractModel):
   
    _name = 'report.fms_sale.sale_invoice_report'        
            
    def get_purchase_date(self,data):
        self.env.cr.execute("""SELECT TO_CHAR(po.date_order,'dd-MM-YY') as date_order FROM purchase_order po
                            JOIN account_invoice ai ON(po.name=ai.origin)WHERE ai.id=%d""" %data.id)
        date_order=self.env.cr.dictfetchall()
        return date_order 
                      
    @api.multi
    def get_report_values(self, ids, data=None):
        report_obj = self.env['account.invoice'].browse(ids)
        return {
            'doc_ids': ids,
            'doc_model': 'account.invoice',
            'docs': report_obj,
            'data': data,
            'get_purchase_date': self.get_purchase_date,            
        }
        
class LeaseInvoiceReport(models.AbstractModel):
   
    _name = 'report.fms_sale.lease_invoice_report'
        
    def job_card_details(self,data):
        where = " "
        line_list = []
        self.env.cr.execute(""" select sale_order_id from sale_order_rel where sale_id = %s """ %(data.id))
        sale_id = self.env.cr.fetchall()
        print ('aaaaaaaaaaaaaaaaa', sale_id)
        for sale in sale_id:
            line_list.append(sale[0])
        print ('1111111111111111', line_list)
        if len(line_list) == 1:
             where+=" so.id = %s"%(tuple(line_list))
        else:
             where+=" so.id in %s"%(tuple(line_list),)        
        print ('whereeeeeeeeeeeeee', where)
        self.env.cr.execute("""select jc.vehicle_number, ppt.name as device_name, jc.chassis_no, TO_CHAR(jc.installation_date, 'dd-MM-YY') as installation_date,
								jc.gsm_number, spl.name as serial_number, rc.name as company_name, pt.installation_location, jc.device_status
                                from division_invoice di 
                                join sale_order_rel sor on(di.id=sor.sale_id)
                                join sale_order so on (so.id=sor.sale_order_id)
                                join project_project pp on (pp.sale_order_id=so.id)
                                join project_task pt on (pt.project_id=pp.id)
                                join job_card jc on (jc.task_id=pt.id)
                                join product_product ppp on (jc.device_id=ppp.id)
                                join product_template ppt on (ppp.product_tmpl_id=ppt.id)
                                join stock_production_lot spl on (jc.device_serial_number_new_id=spl.id)
                                join res_company rc on (jc.company_id=rc.id) where %s""" %(where))
        job_card=self.env.cr.dictfetchall()
        print ('11111111111', job_card)
        return job_card           
              
    @api.multi
    def get_report_values(self, ids, data=None):
        report_obj = self.env['division.invoice'].browse(ids)
        return {      
            'doc_ids': ids,
            'doc_model': 'division.invoice',
            'docs': report_obj,
            'data': data,
            'job_card_details':self.job_card_details,                        
        }
        
class DeliveryReport(models.AbstractModel):
    _name="report.fms_sale.delivery_order_template"
    
    def line_item(self,data):
        self.env.cr.execute(""" select spl.name as lot from stock_production_lot spl where id in 
                                (select distinct (sml.lot_id)from stock_production_lot spl 
                                join stock_move_line sml on (sml.product_id=spl.product_id)
                                join stock_picking sp on (sml.picking_id=sp.id) where sp.id=%s)"""%(data.id))
        lot_obj=self.env.cr.dictfetchall()
        return lot_obj
                                
    @api.model
    def get_report_values(self,docids,data=None):
        delivery_obj=self.env["stock.picking"].browse(docids)
        return {
                'doc_ids':docids,
                'doc_model':"stock.picking",
                'docs':delivery_obj,
                'data':data,
                'line_item': self.line_item,
                
        }
                
class InstallationCertificate(models.AbstractModel):
    _name="report.fms_sale.installation_certificate"
    
    @api.model
    def get_report_values(self,docids,data=None):
        certificate_obj=self.env["installation.certificate"].browse(docids)
        return {
                'doc_ids':docids,
                'doc_model':"installation.certificate",
                'docs':certificate_obj,
                'data':data,
                
        }
